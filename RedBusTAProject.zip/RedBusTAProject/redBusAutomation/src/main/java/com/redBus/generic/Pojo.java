package com.redBus.generic;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

import java.util.Hashtable;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Pojo {

	public static AppiumDriver<?> appiumDriver;
	public static AndroidDriver<?> androidDriver;
	
	public static IOSDriver<?> iOSDriver;
	private WebDriverWait webDriverWait;
	private WebDriverWait appiumDriverWait;
	private Properties objConfig;
	

	// Getter Setter for Appium Driver object instance
	public void setAppiumDriver(AppiumDriver<?> appiumDriver)
	{
		this.appiumDriver = appiumDriver;
	}

	public AppiumDriver<?> getAppiumDriver()
	{
		return appiumDriver;
	}

	// Getter Setter for Android Driver object instance
	public void setAndroidDriver(AndroidDriver<?> androidDriver)
	{
		this.androidDriver = androidDriver;
	}
	


	public AndroidDriver<?> getAndroidDriver()
	{
		return androidDriver;
	}

	// Getter Setter for IOS Driver object instance
	public void appium(IOSDriver<?> iOSDriver)
	{
		this.iOSDriver = iOSDriver;
	}

	public IOSDriver<?> getIOSDriver()
	{
		return iOSDriver;
	}
	
	
	// Getter Setter for Config object instance
		public void setObjConfig(Properties objConfig)
		{
			this.objConfig = objConfig;
		}

		public Properties getObjConfig()
		{
			return objConfig;
		}
	
}
