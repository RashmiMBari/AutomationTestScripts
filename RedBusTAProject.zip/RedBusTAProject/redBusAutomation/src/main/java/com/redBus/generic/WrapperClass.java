package com.redBus.generic;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import java.io.FileInputStream;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;




public class WrapperClass {

	
	private WebDriver webDriver;
	private WebDriverWait webDriverWait;
	private WebDriverWait appiumDriverWait;
	private AppiumDriver<?> appiumDriver;
	private AndroidDriver<?> androidDriver;
	public Properties objConfig;

	
	/**
	 * @Method		: waitForElementPresence
	 * @Description	: This is wrapper method wait for element presence
	 * @param		: locator - By identification of element
	 * @param		: waitInSeconds - wait time 
	 
	 */
	public void waitForElementPresence(By locator) 
	{
		try 
		{
			webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		} 
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
	} 

	
	public boolean mobileClick(WebElement webElement) 
	{
		try
		{
			webElement.click();
			return true;
		} 
		catch (Exception exception)
		{
			exception.printStackTrace();
			return false;
		}
	}

	
	public boolean mobileSetText(WebElement webElement, String fieldValue) 
	{
		try
		{
			Properties objMobileConfig = new Properties();
			objMobileConfig.load(new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/mobileResources/devices/android/" + objConfig.getProperty("test.device") + ".properties"));
			String deviceName= objMobileConfig.getProperty("device.name");

			TouchAction action=new TouchAction((MobileDriver) appiumDriver);
			action.longPress(webElement).release().perform();
			Runtime.getRuntime().exec("adb -s "+deviceName+" shell input text '"+fieldValue+"' ").getInputStream();
			Thread.sleep(1500);
			return true;
		} 
		catch (Exception exception)
		{
			exception.printStackTrace();
			return false;
		}
	}

	
	
	public boolean swipeRight()
	{
		try
		{
			Thread.sleep(1000);
			Dimension size = appiumDriver.manage().window().getSize(); 
			int starty = size.height / 2;
			int startx = (int) (size.width * 0.8);
			int endx = (int) (size.width * 0.20);
			//	appiumDriver.swipe(startx, starty, endx, starty, 1000);
			TouchAction action=new TouchAction((MobileDriver) appiumDriver);
			action.press(startx, starty).waitAction().moveTo(endx, starty).release().perform();
			return true;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			return false;
		}
	}



	public boolean swipeLeft()
	{
		try
		{
			Thread.sleep(2000L);
			Dimension size = appiumDriver.manage().window().getSize(); 
			int starty = size.height / 2;
			int startx = (int) (size.width * 0.04);
			int endx = (int) (size.width * 0.80);
			//	appiumDriver.swipe(startx, starty, endx, starty, 1000);
			TouchAction action=new TouchAction((MobileDriver) appiumDriver);
			action.press(startx, starty).waitAction().moveTo(endx, starty).release().perform();
			return true;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			return false;
		}
	}

	
	public boolean checkElementDisplyed(By locator)
	{
		try 
		{
			return webDriver.findElement(locator).isDisplayed();
		}
		catch(Exception exception)
		{
			return false;
		}
	}



	
}
