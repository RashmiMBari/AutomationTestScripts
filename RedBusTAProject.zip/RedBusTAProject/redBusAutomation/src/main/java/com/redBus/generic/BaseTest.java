package com.redBus.generic;
import java.io.*;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;


public class BaseTest extends Pojo{

	public Properties objConfig;

	
	
	/**
	 * @Method: initializeAndroidEnvironment
	 * @Description:   
	 * @author:  Harshvardhan Yadav (SQS)
	 * @CreationDate:    @ModifiedDate:
	 */
	public AndroidDriver<?> initializeAndroidEnvironment()
	{
		try
		{

			// Load APK/IPA properties file
			objConfig = new Properties();
			objConfig.load(new FileInputStream(System.getProperty("user.dir") + "/src/test/java/config.properties"));
			
			// Set the capabilities for AndroidDriver
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("deviceName", objConfig.getProperty("device.name").trim());
			capabilities.setCapability("udid", objConfig.getProperty("device.name").trim());
			capabilities.setCapability("platformName", objConfig.getProperty("device.platformName").trim());
			capabilities.setCapability("platformVersion", objConfig.getProperty("device.platformVersion").trim());
			capabilities.setCapability("appPackage", objConfig.getProperty("app.Package").trim());
			capabilities.setCapability("appActivity", objConfig.getProperty("app.Activity").trim());
			capabilities.setCapability("appWaitActivity", objConfig.getProperty("app.WaitActivity").trim());
			capabilities.setCapability("newCommandTimeout", objConfig.getProperty("appium.NewCommandTimeout"));
			capabilities.setCapability("sendKeyStrategy", "setValue");

			androidDriver = new AndroidDriver<>(new URL("http://" + objConfig.getProperty("device.appium.ip").trim() + ":" + objConfig.getProperty("device.appium.port").trim() + "/wd/hub"), capabilities);
			androidDriver.manage().timeouts().implicitlyWait(Integer.parseInt(objConfig.getProperty("driver.implicitlyWait")), TimeUnit.SECONDS);
			return androidDriver;

		}
		catch (Exception exception) 
		{
			exception.printStackTrace();
			return null;
		}
	}
	
	
	public void tearDownAndroidEnvironment()
	{
		appiumDriver.quit();
	}
	
	/**
	 * @Method		: 	loadConfigProperties
	 * @Description	: 	load config properties 
	 * @author		:	
	 */
	public void loadConfigProperties()
	{
		try
		{
			objConfig = new Properties();
			objConfig.load(new FileInputStream(System.getProperty("user.dir") + "/src/test/java/config.properties"));
			this.setObjConfig(objConfig);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
	}
	
}
