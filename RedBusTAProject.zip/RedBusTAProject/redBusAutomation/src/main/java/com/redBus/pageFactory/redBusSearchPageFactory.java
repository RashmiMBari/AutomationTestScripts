package com.redBus.pageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import java.util.*;
import java.util.concurrent.TimeUnit;
import com.redBus.generic.Pojo;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import com.redBus.generic.WrapperClass;
import org.testng.Reporter;


public class redBusSearchPageFactory {
	public Properties objConfig;
	public AppiumDriver<?> appiumDriver;
	public Pojo objPojo;
	
	WrapperClass  objWrapperFunctions = new WrapperClass();
	
	public redBusSearchPageFactory(Pojo objPojo)
	{
		objConfig=objPojo.getObjConfig(); 
		appiumDriver=objPojo.getAppiumDriver();
		PageFactory.initElements(
				new AppiumFieldDecorator(
						objPojo.getAppiumDriver(), 
						Integer.parseInt(objPojo.getObjConfig().getProperty("maxwait")), 
						TimeUnit.SECONDS), this); 
	}
	

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='in.redbus.android:id/txtSource']")
	WebElement txtSource;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='in.redbus.android:id/txtDestination']")
	WebElement txtDestination;
	
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='in.redbus.android:id/search_src_text']")
	WebElement enterCityNameTextBox;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='in.redbus.android:id/citySuggest']")
	 List<WebElement> searchCityList;
	
	@AndroidFindBy(xpath = "//android.widget.ImageButton[@resource-id='in.redbus.android:id/imgBtn_search']")
	WebElement searchButton;

	@AndroidFindBy(xpath = "//android.widget.ImageButton[@resource-id='in.redbus.android:id/btnSwap']")
	WebElement swapButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='in.redbus.android:id/travels']")
	List<WebElement> busList ;

	
	/*public void ClickOnHomeMenu()
	{  
		objWrapperFunctions.mobileClick(assetAddImage);
		Reporter.log("Click on Add Asset image button");
	}*/
	
	
	public void ClickOnSourceTxtbox()
	{  
		 objWrapperFunctions.mobileClick(txtSource);
		 Reporter.log("Click on 'From' i.e Source text box");
	}

	public void SetBusStopOrCityName(String strCity)
	{  
		 objWrapperFunctions.mobileSetText(enterCityNameTextBox, strCity);
		 Reporter.log("Set Bus stop or City Name");

	}
	
	public void SelectBusStopOrCityName(String strCity)
	{  
		for(int i =0 ; i < searchCityList.size(); i++) {
		 
			if(searchCityList.get(i).getText().contains(strCity)) {
				
				searchCityList.get(i).click();
			}
		}
		 Reporter.log("Select City or Bus stop name from the list");
	}
	

	public void ClickOnDestinationTxtbox()
	{  
		 objWrapperFunctions.mobileClick(txtDestination);
		 Reporter.log("Click on 'To'i.e Destination text box");
	  
	}
	
	public void ClickOnSearchButton()
	{  
		 objWrapperFunctions.mobileClick(searchButton);
		 Reporter.log("Click on 'Search' button");
	}
	
	public void verifyListOfBusesDisplayed()
	{  
		if( busList.size() > 0) {
		 
			Reporter.log("List of buses are displayed");
		}
	}
	
	
	public void ClickOnSwapButton()
	{  
		 objWrapperFunctions.mobileClick(swapButton);
		 Reporter.log("Click on 'Swap' button");
	}
	
}
