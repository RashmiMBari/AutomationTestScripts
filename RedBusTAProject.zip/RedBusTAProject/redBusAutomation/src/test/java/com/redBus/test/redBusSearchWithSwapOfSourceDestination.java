package com.redBus.test;

import java.util.Properties;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.redBus.generic.BaseTest;
import com.redBus.generic.Pojo;
import com.redBus.pageFactory.*;
import io.appium.java_client.AppiumDriver;

public class redBusSearchWithSwapOfSourceDestination extends BaseTest {

	
	public static AppiumDriver<?> appiumDriver;
	private redBusSearchPageFactory objredBusSearchPageFactory;
	public Properties objConfig;
	private Pojo objPojo;
	
	@BeforeClass
	public void setUpTest()
	{
		appiumDriver =initializeAndroidEnvironment();
		this.setAppiumDriver(appiumDriver);
	}
	
    @Test
	public void TestCase_busSearch()
	{
		objredBusSearchPageFactory.ClickOnSourceTxtbox();
		objredBusSearchPageFactory.SetBusStopOrCityName(objPojo.getObjConfig().getProperty("sourceCity"));
		objredBusSearchPageFactory.SelectBusStopOrCityName(objPojo.getObjConfig().getProperty("sourceCity"));
		objredBusSearchPageFactory.ClickOnDestinationTxtbox();
		objredBusSearchPageFactory.SetBusStopOrCityName(objPojo.getObjConfig().getProperty("destinationCity"));
		objredBusSearchPageFactory.SelectBusStopOrCityName(objPojo.getObjConfig().getProperty("destinationCity"));
		objredBusSearchPageFactory.ClickOnSwapButton();
		objredBusSearchPageFactory.ClickOnSearchButton();
		objredBusSearchPageFactory.verifyListOfBusesDisplayed();
	}

	@AfterClass
	public void endUpTest()
	{
		this.tearDownAndroidEnvironment();
	}
	
}
